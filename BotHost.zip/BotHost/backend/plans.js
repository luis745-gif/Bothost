import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

import {
    createSubscription,
    findActiveSubscription
} from "./database.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const plansPath = path.join(
    __dirname,
    "../config/plans.json"
);

function loadPlans() {
    const content = fs.readFileSync(
        plansPath,
        "utf8"
    );

    return JSON.parse(content);
}

export function getPlans() {
    return loadPlans();
}

export function getPlan(planId) {

    const plans = loadPlans();

    return plans[planId] || null;
}

export function activatePlan(
    userId,
    planId
) {

    const plan = getPlan(planId);

    if (!plan) {
        throw new Error("PLAN_NOT_FOUND");
    }

    const now = new Date();

    const expiresAt = new Date(now);

    expiresAt.setDate(
        expiresAt.getDate() +
        plan.durationDays
    );

    return createSubscription({
        userId,
        planId,
        expiresAt: expiresAt.toISOString()
    });
}

export function getUserPlan(userId) {

    const subscription =
        findActiveSubscription(userId);

    if (!subscription) {
        return null;
    }

    const plan =
        getPlan(subscription.planId);

    return {
        subscription,
        plan
    };
}