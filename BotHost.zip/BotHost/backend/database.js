import fs from "fs";
import path from "path";
import crypto from "crypto";
import dotenv from "dotenv";

dotenv.config();

const databasePath = path.resolve(
    process.env.DATABASE_PATH || "./data/database/bothost.json"
);

const databaseDirectory = path.dirname(databasePath);

if (!fs.existsSync(databaseDirectory)) {
    fs.mkdirSync(databaseDirectory, {
        recursive: true
    });
}

const defaultDatabase = {
    users: [],
    bots: [],
    subscriptions: []
};

function createDatabase() {
    if (!fs.existsSync(databasePath)) {
        fs.writeFileSync(
            databasePath,
            JSON.stringify(defaultDatabase, null, 2)
        );
    }
}

function readDatabase() {
    createDatabase();

    try {
        const content = fs.readFileSync(
            databasePath,
            "utf8"
        );

        return JSON.parse(content);
    } catch (error) {
        console.error("Erro ao ler banco:", error);

        return {
            ...defaultDatabase
        };
    }
}

function saveDatabase(database) {
    fs.writeFileSync(
        databasePath,
        JSON.stringify(database, null, 2)
    );
}

/*
|--------------------------------------------------------------------------
| USUÁRIOS
|--------------------------------------------------------------------------
*/

export function createUser({
    name,
    email,
    passwordHash
}) {

    const database = readDatabase();

    const existingUser = database.users.find(
        user => user.email === email
    );

    if (existingUser) {
        throw new Error("EMAIL_ALREADY_EXISTS");
    }

    const user = {
        id: crypto.randomUUID(),
        name,
        email,
        passwordHash,
        role: "user",
        createdAt: new Date().toISOString()
    };

    database.users.push(user);

    saveDatabase(database);

    return user;
}

export function findUserByEmail(email) {

    const database = readDatabase();

    return database.users.find(
        user => user.email === email
    );
}

export function findUserById(id) {

    const database = readDatabase();

    return database.users.find(
        user => user.id === id
    );
}

/*
|--------------------------------------------------------------------------
| BOTS
|--------------------------------------------------------------------------
*/

export function createBot({
    userId,
    name,
    runtime = "node",
    command = "npm start"
}) {

    const database = readDatabase();

    const bot = {
        id: crypto.randomUUID(),
        userId,
        name,
        runtime,
        command,
        status: "offline",
        createdAt: new Date().toISOString()
    };

    database.bots.push(bot);

    saveDatabase(database);

    return bot;
}

export function findBotById(id) {

    const database = readDatabase();

    return database.bots.find(
        bot => bot.id === id
    );
}

export function findBotsByUser(userId) {

    const database = readDatabase();

    return database.bots.filter(
        bot => bot.userId === userId
    );
}

export function updateBot(id, changes) {

    const database = readDatabase();

    const bot = database.bots.find(
        bot => bot.id === id
    );

    if (!bot) {
        return null;
    }

    Object