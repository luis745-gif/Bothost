const form =
    document.getElementById("loginForm");

const message =
    document.getElementById("message");

form.addEventListener(
    "submit",
    async (event) => {

        event.preventDefault();

        const email =
            document.getElementById(
                "email"
            ).value;

        const password =
            document.getElementById(
                "password"
            ).value;

        message.textContent =
            "Entrando...";

        try {

            const response =
                await fetch(
                    "/api/auth/login",
                    {
                        method: "POST",

                        headers: {
                            "Content-Type":
                                "application/json"
                        },

                        body: JSON.stringify({
                            email,
                            password
                        })
                    }
                );

            const data =
                await response.json();

            if (!data.success) {

                message.textContent =
                    data.message;

                return;
            }

            localStorage.setItem(
                "bothost_token",
                data.token
            );

            window.location.href =
                "/";

        } catch (error) {

            message.textContent =
                "Erro de conexão com o servidor.";
        }
    }
);