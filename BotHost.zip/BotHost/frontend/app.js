 async function verificarUsuario() {

    const token =
        localStorage.getItem(
            "bothost_token"
        );

    if (!token) {

        window.location.href =
            "/login.html";

        return;
    }

    try {

        const response =
            await fetch(
                "/api/auth/me",
                {
                    headers: {
                        Authorization:
                            `Bearer ${token}`
                    }
                }
            );

        if (!response.ok) {

            localStorage.removeItem(
                "bothost_token"
            );

            window.location.href =
                "/login.html";

            return;
        }

        const data =
            await response.json();

        console.log(
            "Usuário:",
            data.user
        );

        document.getElementById(
            "status"
        ).textContent =
            `🟢 Olá, ${data.user.name}`;

    } catch (error) {

        console.error(error);

    }
}

verificarUsuario();