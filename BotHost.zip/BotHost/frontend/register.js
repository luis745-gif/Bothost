const form =
    document.getElementById(
        "registerForm"
    );

const message =
    document.getElementById(
        "message"
    );

form.addEventListener(
    "submit",
    async (event) => {

        event.preventDefault();

        const name =
            document.getElementById(
                "name"
            ).value;

        const email =
            document.getElementById(
                "email"
            ).value;

        const password =
            document.getElementById(
                "password"
            ).value;

        message.textContent =
            "Criando conta...";

        try {

            const response =
                await fetch(
                    "/api/auth/register",
                    {
                        method: "POST",

                        headers: {
                            "Content-Type":
                                "application/json"
                        },

                        body: JSON.stringify({
                            name,
                            email,
                            password
                        })
                    }
                );

            const data =
                await response.json();

            if (!data.success) {

                message.textContent =
                    data.message;

                return;
            }

            localStorage.setItem(
                "bothost_token",
                data.token
            );

            window.location.href =
                "/";

        } catch (error) {

            message.textContent =
                "Erro de conexão com o servidor.";
        }
    }
);